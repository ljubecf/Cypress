// • Login kao administrator (admin@gmail.com)
// • Registrovati novu instituciju (podatke staviti proizvoljno)
// • Login kao korisnik Marko (marko@gmail.com, Bar5slova)
// • Otvoriti kvar koji je Marko kreirao i otvoriti dijalog za izmenu odgovornog lica
// • Testirati polje za pretragu u dijalogu za izbor odgovornog lica
// • Postaviti novododatu instituciju kao odgovorno lice
// • Login kao registrovana institucija
// • Proveriti da li se na stranici dodeljeni kvarovi nalazi dodeljeni kvar
// Ostaviti komentar u okviru kvara sa tekstom “Odbijeno”
// • Ponovo otvoriti stranicu kvara i proslediti kvar nekom drugom korisniku
// • Proveriti da se na stranici dodeljeni kvarovi više ne nalazi kvar
// • Logout 

describe('Dodavanje date institucije', () => {


it('pozitivan test na kom dodajemo datu instituciju', () => {

    cy.login('admin@gmail.com', 'Bar5slova');
    cy.contains('Institucije').click()

    cy.addInstitution('institucijaaa@gmail.com', 'Bar5slova', 'Hladna', 'Novi Sad', 'Moja', '811', '0637064339')

    cy.get('.col-lg-9 > .btn-primary').click()         

    cy.get('.toast-message')
        .should('contain', 'Uspesno ste registrovali instituciju')      
    cy.contains('Pregled').click()   

    cy.get('#filter')  
        .type('institucijaaa@gmail.com')

    cy.get('.row > .btn').click()       

    cy.get('table')
        .find('tbody>tr')
        .should('contain', 'institucijaaa@gmail.com')   
        
        
        cy.get('.nav > :nth-child(2) > .btn').click()     //klik na izlogovati se

        cy.go('back')       //pokusaj da se vratimo na pocetnu klikom na back

        cy.get('.loginForm')
            .should('contain', 'Logovanje') //provera da smo ipak na stranici za logovanje

        cy.url()
            .should('include', '/logovanje')

            cy.login('marko@gmail.com', 'Bar5slova');
             cy.get('#zgradaStanuje > tbody > tr > :nth-child(4)').click()

             cy.get(':nth-child(4) > .nav-link').click()

             cy.get('.pogledaj_1 > .operacije').click()

             cy.get('.izmeni_odgovornog > .operacije').click()

             cy.get('#prikaz').select('50')   
        
             cy.get('.col-form-label > .form-control')
             .type('Hladna') //proveravamo da li je nasa institucija tu
                 
         
 
                cy.get('table')
             .find('tbody>tr')
             .should('contain', 'Hladna')

             cy.get('table')
            .find('tbody>tr')
            .contains('Hladna')
            .siblings().last().as('hladnodugme')    

        cy.get('@hladnodugme').click({  waitForAnimations: false })


        cy.get('.toast-message')
        .should('contain', 'Odgovorno lice uspesno izmenjeno')

         
        cy.get('.nav > :nth-child(2) > .btn').click()     //klik na izlogovati se

        cy.go('back')       //pokusaj da se vratimo na pocetnu klikom na back

        cy.get('.loginForm')
            .should('contain', 'Logovanje') //provera da smo ipak na stranici za logovanje

        cy.login('institucijaaa@gmail.com', 'Bar5slova');
        cy.contains('Dodeljeni kvarovi').click()

        cy.get('table')
        .find('tbody>tr')
        .contains('Ne radi svetlo u hodniku.')

        cy.get('.pogledaj_1').click()

        cy.get(':nth-child(4) > .nav-link').click()

        cy.get('.pogledaj_1 > .operacije')
        .click()

        cy.get('#tekstKomentara')
        .clear()
        .type('Odbijeno')
        cy.get('#button_komentar').click()

        cy.get('.toast-message')
        .should('contain','Komentar uspesno dodat')


        cy.get('.prosledi > .operacije').click()

        cy.get('#prikaz').select('50')

        cy.get('table')
            .find('tbody>tr')
            .contains('Steva Stevanovic')
            .siblings().last().as('steva')    

        cy.get('@steva').click({  waitForAnimations: false })

        cy.get('.toast-message')
        .should('contain', 'Odgovorno lice uspesno izmenjeno')

        cy.get('.mr-auto > :nth-child(2) > .nav-link').click()

        cy.get('app-kvarovi-odgovornog-lica.ng-star-inserted')
        .should('not.contain','Ne radi svetlo u hodniku.')

        cy.get('app-kvarovi-odgovornog-lica.ng-star-inserted')
        .should('not.have.text','Ne radi svetlo u hodniku.')

        


})

 
after(() => {
    cy.contains('Izlogujte se').click()     
    cy.get('.loginForm')
        .should('contain', 'Logovanje') 

    cy.url()
        .should('include', '/logovanje')   
})


})