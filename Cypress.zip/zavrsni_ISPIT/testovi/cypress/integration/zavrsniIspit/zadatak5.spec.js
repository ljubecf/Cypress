// 5. Testirati dropdown na stranici Sastanci skupštine
// • Ulogovati se kao predsednik skupštine (predSkup@gmail.com, Bar5slova)
// • Otvoriti stranicu zgrade u kojoj predsednik živi
// • Preći na tab Sastanci skupštine
// • Napisati testove za dropdown, koji služi za filtriranje sastanaka skupštine
// • Logout preko cy.request komande


describe('Testiranje skupstine', () => {

    beforeEach(() => {
        cy.login('predSkup@gmail.com', 'Bar5slova');
        cy.get(':nth-child(4) > a').click()
        cy.get('.nav > :nth-child(3) > .nav-link')
        .click()
        cy.get('#prikaz').select('50')
    })

    it('Testiramo padajuci meni za sastanke u toku', ()  => {
        cy.get('.custom-select')
        .select('Sastanci u toku')   //testiranje da li prikazuje sastanke u toku

        cy.get('table')
        .find('tbody >tr')
        .should('contain','SASTANAK JE U TOKU')

        cy.get('tbody>tr')
        .should('have.length', 5)  // ovako je morao i ako ima samo jedan sastank dodatna assertacija

        cy.get(':nth-child(4) > .row')
        .should('have.length',1) 
    })
    it('Testiramo padajuci meni za buduce sastanke', ()  => {

   cy.get('.custom-select')
        .select('Buduci Sastanci')   //testiranje da li prikazuje buduce sastanke

        cy.get('table')
        .find('tbody >tr')
        .should('contain','')

        cy.get('tbody>tr')
        .should('have.length', 0)  

    })

    it('Testiramo padajuci meni za prosle sastanke', ()  => {

        cy.get('.custom-select')
             .select('Prosli Sastanci')   //testiranje da li prikazuje prosle sastanke
     
             cy.get('table')
             .find('tbody >tr')
             .should('contain','SASTANAK JE ZAVRSEN')

             cy.get('tbody>tr')
             .should('have.length', 10)  // i ako ima dva sastanak dodatna assertacija
     
     
     
         })

         it('Testiramo padajuci meni za sve sastanke', ()  => {

            cy.get('.custom-select')
                 .select('Svi')   //testiranje da li prikazuje sve sastanke
         
                 cy.get(':nth-child(4) > .row')
                 .should('contain','SASTANAK JE U TOKU')

                 cy.get(':nth-child(5) > .row')
                 .should('contain','SASTANAK JE ZAVRSEN')

                 cy.get(':nth-child(6) > .row')
                 .should('contain','SASTANAK JE ZAVRSEN')
         
                 cy.get('tbody>tr')
                 .should('have.length', 15)  // ovako je morao ako nije velicina dodatna assertacija
         
             })


            
             after(() => {
                cy.logOut2()
            })

})