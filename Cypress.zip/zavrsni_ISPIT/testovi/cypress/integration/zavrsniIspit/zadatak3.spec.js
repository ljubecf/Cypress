// Ulogovati se kao administrator (admin@gmail.com, Bar5slova)
// • Preći na stranicu sa firmama
// • Otvoriti Pregled
// • Testirati polje za pretragu firmi

describe('Testiramo polje za pretragu firme', () => {

    beforeEach(() => {
        
        cy.login('admin@gmail.com', 'Bar5slova');
        cy.contains('Firme').click()
        cy.contains('Pregled').click()
        cy.get('#prikaz').select('50')
    })

    it('Pretraga firme koja vec postoji uneli', () => {

        cy.get('#filter')
            .clear()
            .type('firma1@gmail.com')        //firma koju smo uneli u prvom zadatku
        cy.contains('Pretraga').click()

        cy.get('table')
            .find('tbody>tr')
            .should('contain', 'firma1@gmail.com')
            .and('have.length', 1)

    })

    it('pretraga samo sa nazivom firme', () => {

        cy.get('#filter')
            .clear()
            .type('Firma 1')          //naziv prve firme koju smo uneli u prvom zadatku

        cy.contains('Pretraga').click()

        cy.get('table')
            .find('tbody>tr')
            .should('contain', 'firma1@gmail.com')        
            .and('have.length',1)

    })

    it('Pretraga sa samo delom emaila', () => {

        cy.get('#filter')
            .clear()
            .type('ma1@')      

        cy.contains('Pretraga').click()

        cy.get('table')
            .find('tbody>tr')
            .should('contain', 'firma1@gmail.com')          //email prve firme koju smo uneli u prvom zadatku
            .and('have.length', 1)
    })

    it('Pretraga ne unoseci nista', () => {

        cy.get('#filter')
            .type('aaa')
            .clear()            

        cy.contains('Pretraga').click()
                                                //broj firmi kojih sam uneo u prvom zadataku je 5
        cy.get('tbody>tr')
            .should('have.length', 5)   

    })

    it('Pretraga unoseci nepostojece karaktere', () => {

        cy.get('#filter')
            .clear()
            .type('$$')

        cy.contains('Pretraga').click()

        cy.get('h2')
            .should('contain', 'Nijedna firma sa trazenim kriterijumom nije prondajena!') 
    })
})


