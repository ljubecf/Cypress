//Testirati dodavanje, izmenu i brisanje komentara u okviru kvarova
// Ulogovati se kao Marko (marko@gmail.com, Bar5slova)
// • Otvoriti stranicu zgrade u kojoj Marko živi
// • Preći na tab za kvarove
// • Otvoriti stranicu za kvar koji je Marko kreirao
// • Napisati testove za dodavanje, izmenu i brisanje komentara na tom kvaru
// • Logout

describe('Testiranje dodavanja, izmene i brisanja kvara', () => {

    beforeEach(() => {
        cy.login('marko@gmail.com', 'Bar5slova');

        cy.get('#zgradaStanuje>tbody>tr>:nth-child(4)>a').click()       
        cy.get(':nth-child(4) > .nav-link').click() 

        cy.get('.pogledaj_1 > .operacije').click() 
    })

    it('Testiramo dodavanje kvara', () => {

        cy.get('#tekstKomentara')
            .clear()
            .type('Popravite intefon na prednjem ulazu')

        cy.get('#button_komentar').click()

        cy.get('.komentar > .row')
            .should('contain', 'Popravite intefon na prednjem ulazu')
    })

    it('Izmena komentara', () => {

        cy.get('.kom_2_izmeni > .operacije').click()        

        cy.get('#kom_2_novi_tekst')     
            .type('{backspace}')       
            .type('{backspace}')
            .type('!!')

        cy.get('.kom_2_potvrdi > .operacije').click()

        cy.get('.toast-message')
            .should('contain', 'Komentar uspesno izmenjen')

        cy.get('.komentar > .row')
            .should('contain', 'Popravite intefon na prednjem ula!!')
    })

    it('Brisanje Komentara', () => {

        cy.get('.kom_2_brisi > .operacije').click()    

        cy.get('.toast-message')
            .should('contain', 'Komentar uspesno izbrisan')
    })

    it('Proveravamo unosenje entera i spejsova', () => {

        cy.get('#tekstKomentara')
            .type('    ')           

        cy.get('#button_komentar')
            .should('be.disabled')          
        cy.get('#tekstKomentara')
            .clear()                  
            .type('{enter}')
            .type('{enter}')           
            .type('{enter}')

        cy.get('#button_komentar')    
            .should('be.disabled')

        cy.get('#tekstKomentara')
            .type('    ')

        cy.get('#button_komentar')        
            .should('be.disabled')
    })

after(() => {
    cy.contains('Izlogujte se').click()     
    cy.get('.loginForm')
        .should('contain', 'Logovanje') 

    cy.url()
        .should('include', '/logovanje')   
})

})