// Login kao administrator (admin@gmail.com, Bar5slova)
// • Preći na stranicu sa firmama i istestirati sva polja forme za dodavanje firme
// • Dodati firmu sa sledećim podacima:
// • Email: firma1@gmail.com
// • Lozinka: Bar5slova
// • Naziv: Firma 1
// • Mesto: Novi Sad
// • Ulica: Laze Nančića
// • Broj: 36
// • Broj telefona: 1122334455
// • Proveriti da li je firma uspešno registrovana (proveriti na dva različita načina)
// • Logout

describe('Dodavanje firme', () => {

    beforeEach(() => {
        cy.login('admin@gmail.com', 'Bar5slova');
        cy.contains('Firme').click()
    })




    it('pozitivan test na kom dodajemo datu Firmu', () => {

        cy.addFirma('firma1@gmail.com', 'Bar5slova', 'Firma 1', 'Novi Sad', 'Laze Nančića', '36', '1122334455')

        cy.get('.col-lg-9 > .btn-primary').click()         

        cy.get('.toast-message')
            .should('contain', 'Uspesno ste registrovali firmu')     

        cy.contains('Pregled').click()   

        cy.get('#filter')  
            .type('firma1@gmail.com')

        cy.get('.row > .btn').click()      
        cy.get('table')
            .find('tbody>tr')
            .should('contain', 'firma1@gmail.com')    
        })

        it('dodajemo vec postojecu firmu', () => {

            cy.addFirma('firma1@gmail.com', 'Bar5slova', 'Firma 1', 'Novi Sad', 'Laze Nančića', '36', '1122334455')
    
            cy.get('.col-lg-9 > .btn-primary').click()
    
            cy.get('.toast-message')
                .should('contain', 'E-mail adresa: firma1@gmail.com je zauzeta!')
        })
        

        it('Testiramo input polje za email', () => {

            cy.get('#email')
                .clear()
                .type('aaaaaa')
    
            cy.get('.invalid-feedback')
                .should('contain', 'Neispravna email adresa!')
           
            cy.get('#email')
                .clear()
                .type('a@a')        
    
            cy.get('.invalid-feedback')
                .should('contain', 'Neispravna email adresa!')
           
    
            cy.get('.invalid-feedback')
                .should('contain', 'Neispravna email adresa!')
            
            cy.get('#email')
                .clear()
                .type('a@a.a')      
    
            cy.get('.invalid-feedback')
                .should('contain', 'Neispravna email adresa!')
          
            cy.get('#email')
                .clear()
                .type('a@a.aa')      
    
            cy.get('.invalid-feedback')
                .should('not.be.exist')
        })

        it('Testiramo input polje za lozinku', () => {

            cy.get('#lozinka')
            .clear()
            .type('aaaaaaa') 
           
            cy.get('#lozinka')
            .clear()
            .type('AAAAAAA') 
           
            cy.get('#lozinka')
            .clear()
            .type('1111111') 
           

            cy.get('#lozinka')
            .clear()
            .type('aaaaa11') 
            
            cy.get('#lozinka')
            .clear()
            .type('AAAA11') 
            

            cy.get('#lozinka')
            .clear()
            .type('AAAA11') 
            
            cy.get('#lozinka')
            .clear()
            .type('AAAaaa') 
            
            cy.get('.invalid-feedback')
            .should('contain', 'Neispravna lozinka!')

        })

        it('space-ovi na input poljima za naziv, mesto i ulicu', () => {

            
            //OVO PADA JER POSTOJI BAG DA PROLAZE SPACE karakteri

            cy.addFirma('firma2@gmail.com', 'Bar6slova', ' ', ' ', ' ', '11', '1122334455')  //na tex polja saljemo samo jedan space
    
             
           cy.get('.col-lg-9 > .btn-primary')
               .should('be.disabled')
        })

        it('Granicne vrednosti za lozinku: 5 karaktera', () => {

            cy.addFirma('firma3@gmail.com', 'Bar6s', 'Firma 3', 'Novi Sad', 'Kninska', '81', '1122334455')
    
            cy.get('.invalid-feedback')
                .should('contain', 'Neispravna lozinka!')
    
            cy.get('.col-lg-9 > .btn-primary')
                .should('be.disabled')
    
        })


        it('Granicne vrednosti za lozinku: 7 karaktera', () => {

            cy.addFirma('firma4@gmail.com', 'Bar6slo', 'Firma 4', 'Novi Sad', 'Jovina', '9', '1122334455')
    
            cy.get('.col-lg-9 > .btn-primary')
                .click()
    
            cy.get('.toast-message')
                .should('contain', 'Uspesno ste registrovali firmu')      
    
            cy.contains('Pregled').click()   
    
            cy.get('#filter') 
                .type('firma4@gmail.com')
    
    
            cy.get('.row > .btn').click()      
    
            cy.get('table')
                .find('tbody>tr')
                .should('contain', 'firma4@gmail.com')
        })

        it('Granicne vrednosti za lozinku: 8 karaktera', () => {

            cy.addFirma('firma5@gmail.com', 'Bar6slov', 'Firma 5', 'Novi Sad', 'Bulevar Oslobodjenja', '9', '1122334455')
    
            cy.get('.col-lg-9 > .btn-primary')
                .click()
    
            cy.get('.toast-message')
                .should('contain', 'Uspesno ste registrovali firmu')     
    
            cy.contains('Pregled').click()   
    
            cy.get('#filter')  
                .type('firma5@gmail.com')
    
    
            cy.get('.row > .btn').click()      
    
            cy.get('table')
                .find('tbody>tr')
                .should('contain', 'firma5@gmail.com')
        })

        it('Granicne vrednosti za broj: 8 karaktera', () => {

            cy.addFirma('firma6@gmail.com', 'Bar6slovaA', 'Firma 6', 'Novi Sad', 'Masarikova', '10', '12345678')
    
            cy.get('.invalid-feedback')
            .should('contain', 'Broj mora imati najmanje 9 cifara!')
            cy.get('.col-lg-9 > .btn-primary')
                .should('be.disabled')
    
        })

        it('Granicne vrednosti za broj: 10 karaktera', () => {

            cy.addFirma('firma7@gmail.com', 'Bar6slovaA', 'Firma 7', 'Novi Sad', 'Novinarska', '10', '1234567891')
    
            cy.get('.col-lg-9 > .btn-primary')
            .click()

        cy.get('.toast-message')
            .should('contain', 'Uspesno ste registrovali firmu')     

        cy.contains('Pregled').click()    

        cy.get('#filter')   
            .type('firma7@gmail.com')


        cy.get('.row > .btn').click()      
        cy.get('table')
            .find('tbody>tr')
            .should('contain', 'firma7@gmail.com')
    
        })

        it('Granicne vrednosti za broj: 11 karaktera', () => {

            cy.addFirma('firmaJ@gmail.com', 'Bar6slovaA', 'Firma J', 'Novi Sad', 'Bulevar Oslobodjenja', '10', '12345678910')
    
            cy.get('.col-lg-9 > .btn-primary')
                .click()
    
            cy.get('.toast-message')
                .should('contain', 'Uspesno ste registrovali firmu')      
    
            cy.contains('Pregled').click()   
    
            cy.get('#filter')   
                .type('firmaJ@gmail.com')
    
    
            cy.get('.row > .btn').click()       
    
            cy.get('table')
                .find('tbody>tr')
                .should('contain', 'firmaJ@gmail.com')
        })
    
       
    
        it('Prazna polja u svim inputima', () => {
    
            cy.get('#email')
            .clear()
            .invoke('val', '')
             
    
            cy.get('#lozinka')
            .clear()
            .invoke('val', '')
              
    
            cy.get('#naziv')
            .clear()
            .invoke('val', '')
             
    
            cy.get('#mesto')
            .clear()
            .invoke('val', '')
              
    
            cy.get('#ulica')
            .clear()
            .invoke('val', '')
                
    
            cy.get('#broj')
            .clear()
            .invoke('val', '')
               
    
            cy.get('#brojTelefona')
            .clear()
            .invoke('val', '')
                
    
            cy.get('.invalid-feedback')
                .should('contain', 'Ovo polje ne sme biti prazno!')
    
            cy.get('.col-lg-9 > .btn-primary')
                .should('be.disabled')
        })
    
        it('Pokusamo uneti nesto sto nije broj u polja za broj', () => {
    
            cy.get('#broj')
                .clear()
                .type('dva')
                .should('be.empty')         
    
            cy.get('#brojTelefona')
                .clear()
                .type('dva')
                .should('be.empty')
    
        })


        after(() => {
            cy.contains('Izlogujte se').click()     
            cy.get('.loginForm')
                .should('contain', 'Logovanje') 
    
            cy.url()
                .should('include', '/logovanje')   
        })


})